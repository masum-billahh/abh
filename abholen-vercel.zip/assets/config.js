// Where the WordPress backend lives (the "Abholen Pickup" plugin on repan.ch).
// Must match the "API base URL" shown on the Abholen screen in wp-admin.
// If you change the domain here, also update connect-src in vercel.json.
window.ABHOLEN_API_BASE = "https://repan.ch/wp-json/abholen/v1";
